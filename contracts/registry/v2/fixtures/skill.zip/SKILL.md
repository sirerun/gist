---
name: publication-fixture
description: Verify exact owned publication bytes.
---
Use only the synthetic controlled local fixture.
